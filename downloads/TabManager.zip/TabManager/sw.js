const STORAGE_KEY = "tw_data";

function uid(prefix = "id") {
  return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}

function isUnsupportedUrl(url) {
  if (!url) return true;
  return (
    url.startsWith("chrome-extension://") ||
    url.startsWith("view-source:") ||
    url.startsWith("chrome://")
  );
}

const DEFAULT_COLLECTIONS = ["Shopping", "Inspiration", "Recipes", "Projects", "Travel"];
const LEGACY_SWEDISH_COLLECTIONS = ["Att köpa", "Inspiration", "Recept", "Projekt", "Resor"];

function buildDefaultFolders() {
  return [
    { id: "inbox", name: DEFAULT_COLLECTIONS[0] },
    { id: uid("folder"), name: DEFAULT_COLLECTIONS[1] },
    { id: uid("folder"), name: DEFAULT_COLLECTIONS[2] },
    { id: uid("folder"), name: DEFAULT_COLLECTIONS[3] },
    { id: uid("folder"), name: DEFAULT_COLLECTIONS[4] }
  ];
}

async function getData() {
  const res = await chrome.storage.local.get(STORAGE_KEY);
  const data = res[STORAGE_KEY] || {
    folders: buildDefaultFolders(),
    items: [],
    meta: { seededLibrary: true, language: "en" }
  };

  let changed = false;

  if (!Array.isArray(data.folders)) {
    data.folders = [];
    changed = true;
  }
  if (!Array.isArray(data.items)) {
    data.items = [];
    changed = true;
  }
  if (!data.meta || typeof data.meta !== "object") {
    data.meta = { language: "en" };
    changed = true;
  }

  if (data.folders.length === 0) {
    data.folders = buildDefaultFolders();
    data.meta.seededLibrary = true;
    data.meta.language = "en";
    changed = true;
  }

  if (!data.meta.seededLibrary) {
    const isLegacyInboxOnly = data.folders.length === 1
      && data.folders[0]?.id === "inbox"
      && data.folders[0]?.name === "Inbox";

    if (isLegacyInboxOnly) {
      data.folders = buildDefaultFolders();
      changed = true;
    }

    data.meta.seededLibrary = true;
    data.meta.language = "en";
    changed = true;
  }

  if (data.meta.language !== "en") {
    const names = data.folders.map((f) => f.name);
    const matchesLegacy = data.folders.length === LEGACY_SWEDISH_COLLECTIONS.length
      && LEGACY_SWEDISH_COLLECTIONS.every((n) => names.includes(n));

    if (matchesLegacy) {
      data.folders = data.folders.map((f) => {
        const idx = LEGACY_SWEDISH_COLLECTIONS.indexOf(f.name);
        return idx >= 0 ? { ...f, name: DEFAULT_COLLECTIONS[idx] } : f;
      });
      changed = true;
    }

    data.meta.language = "en";
    changed = true;
  }

  const beforeCount = data.items.length;
  data.items = data.items.filter((it) => !isUnsupportedUrl(it.url));
  if (data.items.length !== beforeCount) changed = true;

  if (changed) await setData(data);

  return data;
}

async function setData(data) {
  await chrome.storage.local.set({ [STORAGE_KEY]: data });
}

function getDefaultFolderId(data) {
  const inbox = data.folders.find(f => f.id === "inbox");
  return inbox ? inbox.id : (data.folders[0]?.id || null);
}

async function saveItem(item) {
  const data = await getData();
  const exists = data.items.some((x) => x.url === item.url);
  if (exists) return { ok: true, skipped: true };

  const defaultFolderId = getDefaultFolderId(data);
  const targetFolderId = data.folders.some(f => f.id === item.folderId)
    ? item.folderId
    : defaultFolderId;

  data.items.unshift({
    id: uid("item"),
    folderId: targetFolderId || data.folders[0].id,
    title: item.title || "Untitled",
    price: item.price || "",
    currency: item.currency || "",
    image: item.image || "",
    site: item.site || "",
    url: item.url,
    addedAt: new Date().toISOString(),
    note: ""
  });

  await setData(data);
  return { ok: true, skipped: false };
}

chrome.runtime.onInstalled.addListener(async () => {
  chrome.contextMenus.remove("tw_save", () => {
    chrome.contextMenus.create({
      id: "tw_save",
      title: "Pin to Tabless Library",
      contexts: ["page"]
    });
  });

  const d = await getData();
  await setData(d);
});

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab?.id) return;
  await chrome.sidePanel.open({ tabId: tab.id });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "tw_save" || !tab?.id) return;
  if (isUnsupportedUrl(tab.url)) {
    chrome.runtime.sendMessage({ type: "TW_UPDATED", result: { skipped: true } });
    return;
  }

  const scraped = await chrome.tabs.sendMessage(tab.id, { type: "TW_SCRAPE" }).catch(() => null);

  const payload = scraped?.item || {
    url: tab.url,
    title: tab.title,
    site: new URL(tab.url).hostname
  };
  if (!payload.image && tab.favIconUrl) payload.image = tab.favIconUrl;

  const result = await saveItem(payload);
  chrome.runtime.sendMessage({ type: "TW_UPDATED", result });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg.type === "TW_GET_DATA") {
      const data = await getData();
      sendResponse({ ok: true, data });
      return;
    }

    if (msg.type === "TW_CREATE_FOLDER") {
      const data = await getData();
      const name = (msg.name || "").trim();
      if (!name) return sendResponse({ ok: false });

      data.folders.push({ id: uid("folder"), name });
      await setData(data);
      chrome.runtime.sendMessage({ type: "TW_UPDATED" });
      sendResponse({ ok: true });
      return;
    }

    if (msg.type === "TW_DELETE_FOLDER") {
      const data = await getData();
      const folderId = msg.folderId;
      if (!folderId) return sendResponse({ ok: false });

      data.folders = data.folders.filter((f) => f.id !== folderId);

      if (data.folders.length === 0) {
        data.folders = buildDefaultFolders();
      }

      const fallbackId = getDefaultFolderId(data) || data.folders[0].id;

      data.items = data.items.map((it) =>
        it.folderId === folderId ? { ...it, folderId: fallbackId } : it
      );

      await setData(data);
      chrome.runtime.sendMessage({ type: "TW_UPDATED", activeFolderId: fallbackId });
      sendResponse({ ok: true, activeFolderId: fallbackId });
      return;
    }

    if (msg.type === "TW_DELETE_ITEM") {
      const data = await getData();
      data.items = data.items.filter((x) => x.id !== msg.itemId);
      await setData(data);
      chrome.runtime.sendMessage({ type: "TW_UPDATED" });
      sendResponse({ ok: true });
      return;
    }

    if (msg.type === "TW_MOVE_ITEM") {
      const data = await getData();
      data.items = data.items.map((x) =>
        x.id === msg.itemId ? { ...x, folderId: msg.folderId } : x
      );
      await setData(data);
      chrome.runtime.sendMessage({ type: "TW_UPDATED" });
      sendResponse({ ok: true });
      return;
    }

    if (msg.type === "TW_SAVE_CURRENT_TAB") {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id || !tab.url) return sendResponse({ ok: false });
      if (isUnsupportedUrl(tab.url)) return sendResponse({ ok: false, skipped: true });

      const scraped = await chrome.tabs.sendMessage(tab.id, { type: "TW_SCRAPE" }).catch(() => null);
      const payload = scraped?.item || {
        url: tab.url,
        title: tab.title,
        site: new URL(tab.url).hostname
      };
      if (!payload.image && tab.favIconUrl) payload.image = tab.favIconUrl;

      payload.folderId = msg.folderId;
      const result = await saveItem(payload);
      chrome.runtime.sendMessage({ type: "TW_UPDATED", result });
      sendResponse({ ok: true, result });
      return;
    }

    sendResponse({ ok: false });
  })();

  return true;
});
