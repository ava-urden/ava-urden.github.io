let state = { data: null, activeFolderId: null, search: "" };

const els = {
  folderSelect: document.getElementById("folderSelect"),
  saveBtn: document.getElementById("saveBtn"),
  search: document.getElementById("search"),
  newFolderBtn: document.getElementById("newFolderBtn"),
  deleteFolderBtn: document.getElementById("deleteFolderBtn"),
  folderTiles: document.getElementById("folderTiles"),
  itemsGrid: document.getElementById("itemsGrid"),
  itemsTitle: document.getElementById("itemsTitle"),
  folderDialog: document.getElementById("folderDialog"),
  folderForm: document.getElementById("folderForm"),
  folderName: document.getElementById("folderName"),
  createFolderConfirm: document.getElementById("createFolderConfirm"),
  cancelFolderBtn: document.getElementById("cancelFolderBtn"),
};

function escapeHtml(s) {
  return (s || "").replace(/[&<>"']/g, (m) => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[m]));
}

function getFaviconUrl(rawUrl, rawSite) {
  const candidate = rawUrl || (rawSite ? `https://${rawSite}` : "");
  if (!candidate) return "";
  try {
    const u = new URL(candidate);
    return `chrome://favicon/size/64@2x/${u.origin}/`;
  } catch {
    try {
      const u = new URL(`https://${candidate}`);
      return `chrome://favicon/size/64@2x/${u.origin}/`;
    } catch {
      return "";
    }
  }
}

async function rpc(message) {
  return await chrome.runtime.sendMessage(message);
}

function fireConfetti() {
  const existing = document.getElementById("tw-confetti");
  if (existing) existing.remove();

  const canvas = document.createElement("canvas");
  canvas.id = "tw-confetti";
  canvas.style.cssText = "position:fixed;inset:0;pointer-events:none;z-index:9999;";
  document.body.appendChild(canvas);

  const ctx = canvas.getContext("2d");
  const dpr = window.devicePixelRatio || 1;
  let width = 0;
  let height = 0;

  function resize() {
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  resize();
  const onResize = () => resize();
  window.addEventListener("resize", onResize);

  const colors = ["#ffffff", "#f7f7f7", "#e0e0e0", "#cfe8ff", "#ffe2b3", "#c7f5d9"];
  const pieces = Array.from({ length: 120 }).map(() => ({
    x: Math.random() * width,
    y: -20 - Math.random() * height * 0.6,
    vx: (Math.random() - 0.5) * 2.2,
    vy: Math.random() * 3 + 2.5,
    size: Math.random() * 6 + 4,
    rot: Math.random() * Math.PI,
    rotSpeed: (Math.random() - 0.5) * 0.2,
    color: colors[Math.floor(Math.random() * colors.length)],
    life: Math.random() * 40 + 80
  }));

  let raf = 0;
  function tick() {
    ctx.clearRect(0, 0, width, height);
    for (const p of pieces) {
      p.vy += 0.04;
      p.x += p.vx;
      p.y += p.vy;
      p.rot += p.rotSpeed;
      p.life -= 1;

      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot);
      ctx.fillStyle = p.color;
      ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
      ctx.restore();
    }

    const alive = pieces.some(p => p.life > 0 && p.y < height + 40);
    if (alive) {
      raf = requestAnimationFrame(tick);
    } else {
      cleanup();
    }
  }

  function cleanup() {
    cancelAnimationFrame(raf);
    window.removeEventListener("resize", onResize);
    canvas.remove();
  }

  tick();
}

async function createFolderFromInput() {
  const name = (els.folderName?.value || "").trim();
  if (!name) return false;
  await rpc({ type: "TW_CREATE_FOLDER", name });
  return true;
}

function folderNameById(id) {
  const f = state.data.folders.find(x => x.id === id);
  return f ? f.name : "Unknown collection";
}

function countItemsInFolder(folderId) {
  return state.data.items.filter(it => it.folderId === folderId).length;
}

function getFolderCoverItems(folderId) {
  return state.data.items.filter(it => it.folderId === folderId).slice(0, 4);
}

function renderFolderSelect() {
  const { folders } = state.data;
  els.folderSelect.innerHTML = folders.map(f => (
    `<option value="${f.id}" ${f.id === state.activeFolderId ? "selected":""}>${escapeHtml(f.name)}</option>`
  )).join("");
}

function renderCoverGrid(items) {
  const cells = items.slice(0, 4).map(it => {
    const label = (it.site || it.title || "").trim();
    const letter = label ? label[0].toUpperCase() : "•";
    const cell = it.image
      ? `<img src="${escapeHtml(it.image)}" alt="">`
      : `<div class="coverFallback">${escapeHtml(letter)}</div>`;

    return `<div class="coverCell">${cell}</div>`;
  }).join("");

  return `<div class="tileCover"><div class="coverGrid">${cells}</div></div>`;
}

function renderCoverEmpty(name) {
  const letter = (name || "").trim().slice(0, 1).toUpperCase() || "?";
  return `
    <div class="tileCover tileCover--empty">
      <div class="coverEmpty">${escapeHtml(letter)}</div>
    </div>
  `;
}

function renderFolderTiles() {
  if (!els.folderTiles) return;
  const { folders } = state.data;
  els.folderTiles.innerHTML = folders.map(f => {
    const active = f.id === state.activeFolderId ? "active" : "";
    const count = countItemsInFolder(f.id);
    const coverItems = getFolderCoverItems(f.id);
    const hasCover = coverItems.length >= 4;
    const delBtn = `<button class="tileDel" data-del="${f.id}" title="Delete collection">✕</button>`;
    const cover = hasCover ? renderCoverGrid(coverItems) : renderCoverEmpty(f.name);

    return `
      <div class="tile ${active}" data-open="${f.id}">
        ${cover}
        ${delBtn}
        <div class="tileBody">
          <div class="tileName">${escapeHtml(f.name)}</div>
          <div class="tileMeta">
            <span>${count} ${count === 1 ? "tab" : "tabs"}</span>
            <span>${escapeHtml(f.id === "inbox" ? "DEFAULT" : "CUSTOM")}</span>
          </div>
        </div>
      </div>
    `;
  }).join("");

  if (state.activeFolderId) {
    els.itemsTitle.textContent = folderNameById(state.activeFolderId).toUpperCase();
  }
}

function getVisibleItems() {
  const items = state.data.items.filter(it => it.folderId === state.activeFolderId);
  const q = state.search.trim().toLowerCase();
  if (!q) return items;
  return items.filter(it =>
    (it.title || "").toLowerCase().includes(q) ||
    (it.site || "").toLowerCase().includes(q) ||
    (it.price || "").toLowerCase().includes(q)
  );
}

function renderItems() {
  const items = getVisibleItems();

  if (items.length === 0) {
    els.itemsGrid.innerHTML = `<div class="empty">No tabs in this folder yet.</div>`;
    return;
  }

  els.itemsGrid.innerHTML = items.map(it => {
    const price = it.price ? `${escapeHtml(it.price)} ${escapeHtml(it.currency || "")}`.trim() : "";
    const fallbackIcon = getFaviconUrl(it.url, it.site);
    const imgUrl = it.image || fallbackIcon;
    const img = imgUrl
      ? `<img src="${escapeHtml(imgUrl)}" alt="">`
      : `<div class="thumbFallback">${escapeHtml((it.site || "").replace(/^www\./, "").slice(0, 2).toUpperCase() || "•")}</div>`;

    return `
      <div class="card" data-open-url="${escapeHtml(it.url)}">
        <div class="thumb">${img}</div>
        <div class="meta">
          <div class="cardHeader">
            <div class="cardTitle">${escapeHtml(it.title)}</div>
            <div class="cardActionsInline">
              <button class="iconBtn" data-delete="${it.id}" aria-label="Remove">✕</button>
              <details class="cardMenu">
                <summary aria-label="Actions">•••</summary>
                <div class="cardActions">
                  <select class="small" data-move="${it.id}">
                    ${state.data.folders.map(f => `
                      <option value="${f.id}" ${f.id === it.folderId ? "selected":""}>Move to: ${escapeHtml(f.name)}</option>
                    `).join("")}
                  </select>
                </div>
              </details>
            </div>
          </div>
          <div class="cardSub">
            <span>${escapeHtml(it.site || "")}</span>
            ${price ? `<span>• ${price}</span>` : ``}
          </div>
        </div>
      </div>
    `;
  }).join("");
}

async function load() {
  const res = await rpc({ type: "TW_GET_DATA" });
  state.data = res.data;

  if (!state.activeFolderId || !state.data.folders.some(f => f.id === state.activeFolderId)) {
    state.activeFolderId = state.data.folders[0]?.id || null;
  }

  renderFolderSelect();
  renderFolderTiles();
  renderItems();
}

/* EVENTS */
els.saveBtn.addEventListener("click", async () => {
  const folderId = els.folderSelect.value || state.activeFolderId;
  const res = await rpc({ type: "TW_SAVE_CURRENT_TAB", folderId });
  if (res?.ok && !res?.result?.skipped) fireConfetti();
});

els.folderSelect.addEventListener("change", (e) => {
  state.activeFolderId = e.target.value;
  renderFolderSelect();
  renderFolderTiles();
  renderItems();
});

els.search.addEventListener("input", (e) => {
  state.search = e.target.value;
  renderItems();
});

els.newFolderBtn.addEventListener("click", async () => {
  if (els.folderName) els.folderName.value = "";
  if (els.folderDialog?.showModal) {
    els.folderDialog.showModal();
    return;
  }

  const name = prompt("New collection");
  if (name && name.trim()) {
    await rpc({ type: "TW_CREATE_FOLDER", name: name.trim() });
    await load();
  }
});

els.deleteFolderBtn?.addEventListener("click", async () => {
  const folderId = els.folderSelect.value || state.activeFolderId;
  if (!folderId) return;
  const folderName = folderNameById(folderId);
  const ok = confirm(`Delete folder "${folderName}"? Tabs inside will be moved to another folder.`);
  if (!ok) return;
  await rpc({ type: "TW_DELETE_FOLDER", folderId });
  await load();
});

els.folderForm?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const created = await createFolderFromInput();
  if (!created) return;
  if (els.folderDialog?.close) els.folderDialog.close();
  await load();
});

els.cancelFolderBtn?.addEventListener("click", () => {
  if (els.folderDialog?.close) els.folderDialog.close();
});

/* Click delegation */
document.addEventListener("click", async (e) => {
  const delFolder = e.target?.getAttribute?.("data-del");
  if (delFolder) {
    await rpc({ type: "TW_DELETE_FOLDER", folderId: delFolder });
    return;
  }

  const openFolder = e.target?.closest?.("[data-open]")?.getAttribute?.("data-open");
  if (openFolder) {
    state.activeFolderId = openFolder;
    renderFolderSelect();
    renderFolderTiles();
    renderItems();
    return;
  }

  const delItem = e.target?.getAttribute?.("data-delete");
  if (delItem) {
    await rpc({ type: "TW_DELETE_ITEM", itemId: delItem });
    return;
  }

  const openCard = e.target?.closest?.("[data-open-url]");
  const isAction = !!e.target?.closest?.(".cardMenu, .cardActionsInline, button, select, summary");
  if (openCard && !isAction) {
    const openUrl = openCard.getAttribute("data-open-url");
    if (openUrl) chrome.tabs.create({ url: openUrl });
    return;
  }

  const navJump = e.target?.getAttribute?.("data-jump");
  if (navJump) {
    document.querySelectorAll(".navItem").forEach(b => b.classList.remove("isActive"));
    e.target.classList.add("isActive");
    document.getElementById(navJump)?.scrollIntoView({ behavior: "smooth", block: "start" });
  }
});

document.addEventListener("change", async (e) => {
  const moveId = e.target?.getAttribute?.("data-move");
  if (moveId) {
    const folderId = e.target.value;
    await rpc({ type: "TW_MOVE_ITEM", itemId: moveId, folderId });
  }
});

/* Reload on updates */
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "TW_UPDATED") load();
});

load();
