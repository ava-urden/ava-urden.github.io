chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (!alarm.name.startsWith("task_")) return;
  const { tasks = [] } = await chrome.storage.local.get("tasks");
  const parts = alarm.name.split("_");
  const taskId = parts[1];
  const offset = parts[2];
  const task = tasks.find(t => t.id === taskId);
  if (!task) return;
  const labels = { "1day": "1 dag kvar till deadline!", "1hour": "1 timme kvar!", "attime": "Deadline nu!" };
  chrome.notifications.create(`notif_${taskId}_${offset}`, {
    type: "basic", iconUrl: "icons/icon48.png",
    title: `✓ ${task.title}`, message: labels[offset] || "Deadline snart!", priority: 2
  });
});

async function rescheduleAlarms(tasks) {
  const all = await chrome.alarms.getAll();
  for (const a of all) { if (a.name.startsWith("task_")) await chrome.alarms.clear(a.name); }
  const now = Date.now();
  for (const task of tasks) {
    if (!task.deadline || task.done) continue;
    const dl = new Date(task.deadline).getTime();
    if (isNaN(dl)) continue;
    const offsets = [{ key: "1day", ms: 86400000 }, { key: "1hour", ms: 3600000 }, { key: "attime", ms: 0 }];
    for (const { key, ms } of offsets) { const t = dl - ms; if (t > now) chrome.alarms.create(`task_${task.id}_${key}`, { when: t }); }
  }
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.tasks) rescheduleAlarms(changes.tasks.newValue || []);
});
chrome.runtime.onStartup.addListener(async () => { const { tasks = [] } = await chrome.storage.local.get("tasks"); rescheduleAlarms(tasks); });
chrome.runtime.onInstalled.addListener(async () => { const { tasks = [] } = await chrome.storage.local.get("tasks"); rescheduleAlarms(tasks); });
