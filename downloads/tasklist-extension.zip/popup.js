// ===== STATE =====
let state = {
  tasks: [], folders: [],
  filter: "all",
  folderFilter: "all",
  searchQ: "",
  collapsed: {},
  editingId: null,
  folderColor: "#1A2033"
};

// ===== STORAGE =====
async function load() {
  const d = await chrome.storage.local.get(["tasks", "folders", "collapsed"]);
  state.tasks = d.tasks || [];
  state.folders = d.folders || [];
  state.collapsed = d.collapsed || {};
}
async function save() {
  await chrome.storage.local.set({ tasks: state.tasks, folders: state.folders, collapsed: state.collapsed });
}

// ===== HELPERS =====
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
const esc = s => String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");

function parseDomain(url) {
  try { return new URL(url).hostname.replace("www.", "").toUpperCase(); } catch { return null; }
}

function deadlineInfo(iso) {
  if (!iso) return null;
  const d = new Date(iso), now = new Date();
  const diff = d - now;
  const mins = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  if (diff < 0) return { label: "Försenad", cls: "overdue", card: "overdue" };
  if (mins < 60) return { label: `${mins}min kvar`, cls: "soon", card: "due-soon" };
  if (hours < 24) return { label: `${hours}h kvar`, cls: "soon", card: "due-soon" };
  if (days === 0) return { label: "Idag", cls: "soon", card: "due-soon" };
  if (days === 1) return { label: "Imorgon", cls: "", card: "" };
  return { label: d.toLocaleDateString("sv-SE", { day: "numeric", month: "short" }), cls: "", card: "" };
}

function getVisible() {
  const now = new Date();
  return state.tasks.filter(t => {
    if (state.searchQ) {
      const q = state.searchQ.toLowerCase();
      if (!t.title.toLowerCase().includes(q) && !(t.note || "").toLowerCase().includes(q)) return false;
    }
    if (state.folderFilter !== "all" && t.folderId !== state.folderFilter) return false;
    if (state.filter === "done") return t.done;
    if (state.filter === "all") return !t.done;
    if (state.filter === "today") {
      if (t.done || !t.deadline) return false;
      return new Date(t.deadline).toDateString() === now.toDateString();
    }
    if (state.filter === "upcoming") {
      if (t.done || !t.deadline) return false;
      return new Date(t.deadline) > now;
    }
    return true;
  });
}

// ===== RENDER =====
function render() {
  const list = document.getElementById("task-list");
  const tasks = getVisible();

  // Update folder filter dropdown
  const ffSel = document.getElementById("folder-filter-select");
  const ffVal = ffSel.value;
  ffSel.innerHTML = `<option value="all">Alla mappar</option>`;
  state.folders.forEach(f => {
    const o = document.createElement("option");
    o.value = f.id; o.textContent = f.name;
    if (ffVal === f.id) o.selected = true;
    ffSel.appendChild(o);
  });

  if (tasks.length === 0 && state.folders.filter(f => state.folderFilter === "all" || f.id === state.folderFilter).length === 0) {
    list.innerHTML = `<div class="empty">
      <div class="empty-icon">✓</div>
      <p>Inga uppgifter att visa.</p>
      <small>Klicka "+ Ny uppgift" för att börja.</small>
    </div>`;
    return;
  }

  let html = "";

  // Ungrouped
  const ungrouped = tasks.filter(t => !t.folderId);
  ungrouped.forEach(t => { html += taskCard(t); });

  // Folders
  const visibleFolders = state.folderFilter === "all"
    ? state.folders
    : state.folders.filter(f => f.id === state.folderFilter);

  visibleFolders.forEach(folder => {
    const ft = tasks.filter(t => t.folderId === folder.id);
    const collapsed = state.collapsed[folder.id];
    html += `<div class="folder-label" data-toggle="${folder.id}">
      <div class="folder-dot" style="background:${esc(folder.color)}"></div>
      <span class="folder-label-name">${esc(folder.name)}</span>
      <span class="folder-label-count">${ft.length}</span>
      <span class="folder-caret ${collapsed ? "" : "open"}">▶</span>
    </div>
    <div class="folder-tasks-wrap ${collapsed ? "collapsed" : ""}">
      ${ft.map(t => taskCard(t)).join("")}
    </div>`;
  });

  if (html === "") {
    list.innerHTML = `<div class="empty">
      <div class="empty-icon">✓</div>
      <p>Inga uppgifter att visa.</p>
    </div>`;
    return;
  }

  list.innerHTML = html;
  attachEvents();
}

function taskCard(task) {
  const dl = deadlineInfo(task.deadline);
  const domain = task.link ? parseDomain(task.link) : null;
  const cardCls = [task.done ? "done" : "", dl?.card || ""].filter(Boolean).join(" ");

  const linkEl = task.link
    ? `<a class="link-badge" href="${esc(task.link)}" target="_blank" data-link="1">
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
        ${domain || "Öppna"}
      </a>` : "";

  const dlEl = dl
    ? `<span class="deadline-tag ${dl.cls}">
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
        ${dl.label}
      </span>` : "";

  const noteEl = task.note
    ? `<div class="note-preview">${esc(task.note.slice(0, 65))}${task.note.length > 65 ? "…" : ""}</div>` : "";

  return `<div class="task-card ${cardCls}" data-id="${task.id}">
    <div class="cb ${task.done ? "checked" : ""}" data-check="${task.id}"></div>
    <div class="card-body">
      <div class="task-title">${esc(task.title)}</div>
      <div class="card-meta">${dlEl}${linkEl}</div>
      ${noteEl}
    </div>
    <div class="card-actions">
      <button class="action-btn remove" data-remove="${task.id}" title="Ta bort">✕</button>
      <button class="action-btn edit-btn" data-edit="${task.id}" title="Redigera">✎</button>
    </div>
  </div>`;
}

function attachEvents() {
  document.getElementById("task-list").querySelectorAll("[data-check]").forEach(el => {
    el.addEventListener("click", async e => {
      e.stopPropagation();
      const t = state.tasks.find(x => x.id === el.dataset.check);
      if (t) { t.done = !t.done; await save(); render(); }
    });
  });
  document.getElementById("task-list").querySelectorAll("[data-edit]").forEach(el => {
    el.addEventListener("click", e => { e.stopPropagation(); openTaskModal(el.dataset.edit); });
  });
  document.getElementById("task-list").querySelectorAll("[data-remove]").forEach(el => {
    el.addEventListener("click", async e => {
      e.stopPropagation();
      if (!confirm("Ta bort uppgiften?")) return;
      state.tasks = state.tasks.filter(t => t.id !== el.dataset.remove);
      await save(); render();
    });
  });
  document.getElementById("task-list").querySelectorAll(".task-card").forEach(el => {
    el.addEventListener("click", e => {
      if (e.target.closest("[data-check]") || e.target.closest("[data-link]") || e.target.closest("[data-remove]") || e.target.closest("[data-edit]")) return;
      openTaskModal(el.dataset.id);
    });
  });
  document.getElementById("task-list").querySelectorAll("[data-toggle]").forEach(el => {
    el.addEventListener("click", async () => {
      const fid = el.dataset.toggle;
      state.collapsed[fid] = !state.collapsed[fid];
      await save(); render();
    });
  });
}

// ===== TASK MODAL =====
function openTaskModal(id = null) {
  state.editingId = id;
  const task = id ? state.tasks.find(t => t.id === id) : null;
  document.getElementById("modal-title-label").textContent = task ? "Redigera" : "Ny uppgift";
  document.getElementById("task-title-input").value = task?.title || "";
  document.getElementById("task-link-input").value = task?.link || "";
  document.getElementById("task-note-input").value = task?.note || "";
  document.getElementById("task-deadline-input").value = task?.deadline
    ? new Date(new Date(task.deadline).getTime() - new Date(task.deadline).getTimezoneOffset()*60000).toISOString().slice(0,16) : "";
  const sel = document.getElementById("task-folder-select");
  sel.innerHTML = `<option value="">Ingen</option>`;
  state.folders.forEach(f => {
    const o = document.createElement("option");
    o.value = f.id; o.textContent = f.name;
    if (task?.folderId === f.id) o.selected = true;
    sel.appendChild(o);
  });
  document.getElementById("delete-task-btn").style.display = task ? "inline-flex" : "none";
  document.getElementById("task-modal").classList.remove("hidden");
  setTimeout(() => document.getElementById("task-title-input").focus(), 100);
}
function closeTaskModal() { document.getElementById("task-modal").classList.add("hidden"); state.editingId = null; }

async function saveTask() {
  const title = document.getElementById("task-title-input").value.trim();
  if (!title) { document.getElementById("task-title-input").style.borderColor = "#DC2626"; return; }
  document.getElementById("task-title-input").style.borderColor = "";
  const link = document.getElementById("task-link-input").value.trim();
  const raw = document.getElementById("task-deadline-input").value;
  const note = document.getElementById("task-note-input").value.trim();
  const folderId = document.getElementById("task-folder-select").value || null;
  const deadline = raw ? new Date(raw).toISOString() : null;
  if (state.editingId) {
    const t = state.tasks.find(x => x.id === state.editingId);
    if (t) Object.assign(t, { title, link, deadline, note, folderId });
  } else {
    state.tasks.push({ id: uid(), title, link, deadline, note, folderId, done: false, createdAt: new Date().toISOString() });
  }
  await save(); closeTaskModal(); render();
}

// ===== FOLDER MODAL =====
function openFolderModal() {
  document.getElementById("folder-name-input").value = "";
  state.folderColor = "#1A2033";
  document.querySelectorAll(".cdot").forEach(d => d.classList.toggle("active", d.dataset.c === "#1A2033"));
  document.getElementById("folder-modal").classList.remove("hidden");
  setTimeout(() => document.getElementById("folder-name-input").focus(), 100);
}
function closeFolderModal() { document.getElementById("folder-modal").classList.add("hidden"); }

async function saveFolder() {
  const name = document.getElementById("folder-name-input").value.trim();
  if (!name) { document.getElementById("folder-name-input").style.borderColor = "#DC2626"; return; }
  state.folders.push({ id: uid(), name, color: state.folderColor });
  await save(); closeFolderModal(); render();
}

async function deleteCurrentFolder() {
  const fid = state.folderFilter;
  if (fid === "all") { alert("Välj en specifik mapp att ta bort."); return; }
  const folder = state.folders.find(f => f.id === fid);
  if (!folder) return;
  if (!confirm(`Ta bort mappen "${folder.name}"? Uppgifterna behålls utan mapp.`)) return;
  state.folders = state.folders.filter(f => f.id !== fid);
  state.tasks.forEach(t => { if (t.folderId === fid) t.folderId = null; });
  state.folderFilter = "all";
  await save(); render();
}

// ===== INIT =====
async function init() {
  await load(); render();

  document.getElementById("add-task-btn").addEventListener("click", () => openTaskModal());
  document.getElementById("add-folder-btn").addEventListener("click", openFolderModal);
  document.getElementById("delete-folder-btn").addEventListener("click", deleteCurrentFolder);

  document.getElementById("folder-filter-select").addEventListener("change", e => {
    state.folderFilter = e.target.value; render();
  });

  document.getElementById("search-input").addEventListener("input", e => {
    state.searchQ = e.target.value.trim(); render();
  });

  document.querySelectorAll(".pill").forEach(b => {
    b.addEventListener("click", () => {
      state.filter = b.dataset.filter;
      document.querySelectorAll(".pill").forEach(x => x.classList.toggle("active", x === b));
      render();
    });
  });

  // Task modal
  document.getElementById("close-task-modal").addEventListener("click", closeTaskModal);
  document.getElementById("save-task-btn").addEventListener("click", saveTask);
  document.getElementById("delete-task-btn").addEventListener("click", async () => {
    if (!state.editingId || !confirm("Ta bort uppgiften?")) return;
    state.tasks = state.tasks.filter(t => t.id !== state.editingId);
    await save(); closeTaskModal(); render();
  });
  document.getElementById("task-modal").addEventListener("click", e => {
    if (e.target === document.getElementById("task-modal")) closeTaskModal();
  });

  // Folder modal
  document.getElementById("close-folder-modal").addEventListener("click", closeFolderModal);
  document.getElementById("save-folder-btn").addEventListener("click", saveFolder);
  document.getElementById("folder-modal").addEventListener("click", e => {
    if (e.target === document.getElementById("folder-modal")) closeFolderModal();
  });

  document.getElementById("folder-color-picker").addEventListener("click", e => {
    const dot = e.target.closest(".cdot");
    if (!dot) return;
    state.folderColor = dot.dataset.c;
    document.querySelectorAll(".cdot").forEach(d => d.classList.toggle("active", d === dot));
  });

  document.addEventListener("keydown", e => {
    if (e.key === "Escape") { closeTaskModal(); closeFolderModal(); }
    if (e.key === "Enter" && !document.getElementById("task-modal").classList.contains("hidden") && e.target.tagName !== "TEXTAREA") saveTask();
    if (e.key === "Enter" && !document.getElementById("folder-modal").classList.contains("hidden")) saveFolder();
  });
}

init();
