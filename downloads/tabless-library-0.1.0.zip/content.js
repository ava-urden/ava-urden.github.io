function getMeta(selector) {
  const el = document.querySelector(selector);
  return el?.getAttribute("content")?.trim() || "";
}

function normalizeUrl(url) {
  if (!url) return "";
  try {
    return new URL(url, location.href).toString();
  } catch {
    return url;
  }
}

function pickFromSrcset(srcset) {
  if (!srcset) return "";
  const parts = srcset.split(",").map((p) => p.trim()).filter(Boolean);
  if (parts.length === 0) return "";
  let best = { url: "", score: 0 };
  for (const part of parts) {
    const [url, descriptor] = part.split(/\s+/);
    if (!url) continue;
    let score = 1;
    if (descriptor?.endsWith("w")) {
      score = parseFloat(descriptor) || 1;
    } else if (descriptor?.endsWith("x")) {
      score = (parseFloat(descriptor) || 1) * 1000;
    }
    if (score > best.score) best = { url, score };
  }
  return best.url;
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function typeIncludesProduct(type) {
  if (!type) return false;
  if (Array.isArray(type)) return type.some(typeIncludesProduct);
  if (typeof type === "string") return type.toLowerCase().includes("product");
  return false;
}

function parseJsonLdProducts() {
  const scripts = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));
  const parsed = [];
  for (const s of scripts) {
    try {
      const json = JSON.parse(s.textContent);
      if (Array.isArray(json)) parsed.push(...json);
      else parsed.push(json);
    } catch {}
  }

  const products = [];
  for (const obj of parsed) {
    if (!obj) continue;
    if (typeIncludesProduct(obj["@type"])) products.push(obj);
    if (obj["@graph"]) {
      for (const n of obj["@graph"]) {
        if (typeIncludesProduct(n?.["@type"])) products.push(n);
      }
    }
  }
  return products;
}

function extractPriceFromJsonLd(products) {
  for (const p of products) {
    const offers = p.offers;
    const offer = Array.isArray(offers) ? offers[0] : offers;
    if (!offer) continue;

    const price = offer.price || offer.lowPrice || "";
    const currency = offer.priceCurrency || "";
    if (price) return { price: String(price), currency: String(currency || "") };
  }
  return { price: "", currency: "" };
}

function extractPriceFallback() {
  const selectors = [
    '[itemprop="price"]',
    '[data-testid*="price"]',
    '[data-qa*="price"]',
    '[data-test*="price"]',
    '[class*="price"]',
    '[id*="price"]'
  ];
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (!el) continue;
    const txt = (el.getAttribute("content") || el.textContent || "").trim();
    if (/\d/.test(txt) && txt.length < 40) return txt;
  }
  return "";
}

function extractImageFromJsonLd(products) {
  for (const p of products) {
    const image = p.image;
    if (!image) continue;

    if (typeof image === "string") return normalizeUrl(image);

    if (Array.isArray(image)) {
      for (const entry of image) {
        if (typeof entry === "string") return normalizeUrl(entry);
        if (entry?.url) return normalizeUrl(entry.url);
        if (entry?.contentUrl) return normalizeUrl(entry.contentUrl);
      }
    }

    if (image?.url) return normalizeUrl(image.url);
    if (image?.contentUrl) return normalizeUrl(image.contentUrl);
  }
  return "";
}

function extractImageFromMeta() {
  const selectors = [
    'meta[property="og:image:secure_url"]',
    'meta[property="og:image"]',
    'meta[property="og:image:url"]',
    'meta[name="twitter:image"]',
    'meta[property="twitter:image"]',
    'meta[property="product:image"]'
  ];

  for (const sel of selectors) {
    const content = getMeta(sel);
    if (content) return normalizeUrl(content);
  }

  return "";
}

function isLikelyLogo(img) {
  const hay = `${img.id} ${img.className} ${img.alt}`.toLowerCase();
  return hay.includes("logo") || hay.includes("brand");
}

function getImageFromElement(img) {
  if (!img) return "";
  const direct = img.currentSrc || img.src || img.getAttribute("src");
  if (direct) return normalizeUrl(direct);

  const srcset = img.getAttribute("srcset") || img.getAttribute("data-srcset");
  const fromSet = pickFromSrcset(srcset);
  if (fromSet) return normalizeUrl(fromSet);

  const dataAttrs = ["data-src", "data-original", "data-lazy", "data-zoom-image", "data-hires", "data-image"];
  for (const a of dataAttrs) {
    const v = img.getAttribute(a);
    if (v) return normalizeUrl(v);
  }

  return "";
}

function extractImageFromDom() {
  const selectors = [
    'img[itemprop="image"]',
    'img[data-testid*="image"]',
    'img[data-test*="image"]',
    'img[data-qa*="image"]',
    'img[class*="product"]',
    'img[id*="product"]',
    'img[class*="gallery"]',
    'img[class*="main"]',
    'picture img'
  ];

  let best = { url: "", score: 0 };

  for (const sel of selectors) {
    const nodes = Array.from(document.querySelectorAll(sel));
    for (const img of nodes) {
      if (!(img instanceof HTMLImageElement)) continue;
      if (isLikelyLogo(img)) continue;
      const url = getImageFromElement(img);
      if (!url) continue;
      const w = img.naturalWidth || img.width || 0;
      const h = img.naturalHeight || img.height || 0;
      const area = w * h;
      const score = area > 0 ? area : url.length;
      if (score > best.score) best = { url, score };
    }
    if (best.url) return best.url;
  }

  return best.url;
}

function hasAddToCartSignals() {
  const selectors = [
    '[data-testid*="add-to-cart"]',
    '[data-testid*="addtocart"]',
    '[data-test*="add-to-cart"]',
    '[data-test*="addtocart"]',
    '[data-qa*="add-to-cart"]',
    '[data-qa*="addtocart"]',
    '[data-automation*="add-to-cart"]',
    '[name="add-to-cart"]',
    '[name="add"]',
    '[id*="add-to-cart"]',
    '[class*="add-to-cart"]'
  ];

  for (const sel of selectors) {
    if (document.querySelector(sel)) return true;
  }

  const textMatch = /(add to cart|add to bag|add to basket|buy now|purchase|add to|lägg i varukorg|lägg i kundvagn|köp nu|köp|till varukorg|till kundvagn|lägg i)/i;
  const candidates = Array.from(document.querySelectorAll('button, input[type="submit"], a[role="button"], [role="button"]'));

  for (const el of candidates) {
    const txt = (el.getAttribute("aria-label") || el.getAttribute("title") || el.value || el.textContent || "").trim();
    if (!txt) continue;
    if (textMatch.test(txt)) return true;
  }

  return false;
}

function looksLikeProductPage() {
  const products = parseJsonLdProducts();
  if (products.length > 0) return true;

  const ogType = getMeta('meta[property="og:type"]');
  if (ogType && ogType.toLowerCase().includes("product")) return true;

  if (document.querySelector('[itemtype*="Product" i]')) return true;

  if (document.querySelector('meta[property="product:price:amount"], meta[property="og:price:amount"], meta[itemprop="price"]')) {
    return true;
  }

  if (hasAddToCartSignals()) return true;

  const price = extractPriceFallback();
  if (price && document.querySelector("h1")) return true;

  const path = location.pathname.toLowerCase();
  if (/(\/p\/|\/product\/|\/products\/|\/produkt\/|\/item\/|\/shop\/)/.test(path)) return true;

  return false;
}

function shouldShowWidget() {
  if (location.protocol !== "http:" && location.protocol !== "https:") return false;
  if (looksLikeProductPage()) return true;
  return true; // fallback: always show if detection misses
}

async function rpc(message) {
  return await chrome.runtime.sendMessage(message);
}

function getStorage(key) {
  return new Promise((resolve) => {
    chrome.storage.local.get(key, (res) => resolve(res[key] || null));
  });
}

function setStorage(key, value) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ [key]: value }, () => resolve());
  });
}

function fireConfetti() {
  const existing = document.getElementById("tw-confetti");
  if (existing) existing.remove();

  const canvas = document.createElement("canvas");
  canvas.id = "tw-confetti";
  canvas.style.cssText = "position:fixed;inset:0;pointer-events:none;z-index:2147483646;";
  document.documentElement.appendChild(canvas);

  const ctx = canvas.getContext("2d");
  const dpr = window.devicePixelRatio || 1;
  let width = 0;
  let height = 0;

  function resize() {
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  resize();
  const onResize = () => resize();
  window.addEventListener("resize", onResize);

  const colors = ["#ffffff", "#f7f7f7", "#e0e0e0", "#cfe8ff", "#ffe2b3", "#c7f5d9"];
  const pieces = Array.from({ length: 120 }).map(() => ({
    x: Math.random() * width,
    y: -20 - Math.random() * height * 0.6,
    vx: (Math.random() - 0.5) * 2.2,
    vy: Math.random() * 3 + 2.5,
    size: Math.random() * 6 + 4,
    rot: Math.random() * Math.PI,
    rotSpeed: (Math.random() - 0.5) * 0.2,
    color: colors[Math.floor(Math.random() * colors.length)],
    life: Math.random() * 40 + 80
  }));

  let raf = 0;
  function tick() {
    ctx.clearRect(0, 0, width, height);
    for (const p of pieces) {
      p.vy += 0.04;
      p.x += p.vx;
      p.y += p.vy;
      p.rot += p.rotSpeed;
      p.life -= 1;

      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot);
      ctx.fillStyle = p.color;
      ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
      ctx.restore();
    }

    const alive = pieces.some(p => p.life > 0 && p.y < height + 40);
    if (alive) {
      raf = requestAnimationFrame(tick);
    } else {
      cleanup();
    }
  }

  function cleanup() {
    cancelAnimationFrame(raf);
    window.removeEventListener("resize", onResize);
    canvas.remove();
  }

  tick();
}

function mountWidget() {
  if (document.getElementById("tw-widget-host")) return;

  const host = document.createElement("div");
  host.id = "tw-widget-host";
  const shadow = host.attachShadow({ mode: "open" });

  const fontRegular = chrome.runtime.getURL("fonts/Lato-400.ttf");
  const fontBold = chrome.runtime.getURL("fonts/Lato-700.ttf");
  const pinUrl = chrome.runtime.getURL("icons/save.png");

  shadow.innerHTML = `
    <style>
      @font-face {
        font-family: "Lato";
        font-style: normal;
        font-weight: 400;
        font-display: swap;
        src: url("${fontRegular}") format("truetype");
      }
      @font-face {
        font-family: "Lato";
        font-style: normal;
        font-weight: 700;
        font-display: swap;
        src: url("${fontBold}") format("truetype");
      }
      :host{
        position: fixed;
        right: 18px;
        bottom: 18px;
        z-index: 2147483647;
        font-family: "Lato", "Helvetica Neue", Arial, sans-serif;
        color: #2b2b2b;
      }
      .tw-wrap{ position: relative; }

      .tw-button{
        all: unset;
        width: 46px;
        height: 46px;
        background: rgba(255,255,255,0.94);
        color: #1d1d1d;
        border-radius: 999px;
        font-weight: 700;
        font-size: 14px;
        letter-spacing: 0.02em;
        cursor: grab;
        user-select: none;
        -webkit-user-select: none;
        touch-action: none;
        box-shadow: 0 16px 30px rgba(0,0,0,0.16);
        border: 1px solid rgba(0,0,0,0.08);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: transform 120ms ease, box-shadow 120ms ease;
      }
      .tw-button:hover{ box-shadow: 0 20px 40px rgba(0,0,0,0.18); }
      .tw-button:active{ transform: translateY(1px); }
      .tw-button[disabled]{ opacity: 0.7; cursor: default; }
      .tw-button.tw-dragging{ cursor: grabbing; }

      .tw-pin-img{
        width: 22px;
        height: 22px;
        display: block;
        object-fit: contain;
      }

      .tw-visually-hidden{
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0,0,0,0);
        white-space: nowrap;
        border: 0;
      }

      .tw-panel{
        position: absolute;
        right: 0;
        bottom: 60px;
        width: 260px;
        background: rgba(255,255,255,0.96);
        border: 1px solid rgba(0,0,0,0.08);
        border-radius: 20px;
        box-shadow: 0 18px 40px rgba(0,0,0,0.16);
        padding: 14px;
      }
      .tw-title{
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0.18em;
        text-transform: uppercase;
        color: #6b6b6b;
        margin: 4px 6px 6px;
      }
      .tw-status{
        font-size: 13px;
        color: #5b5b5b;
        margin: 0 6px 12px;
      }
      .tw-list{
        display: flex;
        flex-direction: column;
        gap: 8px;
        max-height: 220px;
        overflow: auto;
        padding: 2px 4px 4px;
      }
      .tw-folder{
        all: unset;
        border: 1px solid rgba(0,0,0,0.08);
        background: rgba(255,255,255,0.96);
        border-radius: 16px;
        padding: 12px 12px;
        cursor: pointer;
        font-weight: 700;
        font-size: 14px;
        color: #2b2b2b;
        transition: background 140ms ease, border-color 140ms ease, transform 120ms ease, box-shadow 120ms ease;
      }
      .tw-folder:hover{
        background: rgba(248,248,248,1);
        border-color: rgba(0,0,0,0.12);
        transform: translateY(-1px);
        box-shadow: 0 8px 16px rgba(0,0,0,0.10);
      }
      .tw-create{
        margin-top: 10px;
        display: grid;
        grid-template-columns: 1fr auto;
        gap: 8px;
      }
      .tw-input{
        all: unset;
        padding: 10px 12px;
        border-radius: 14px;
        border: 1px solid rgba(0,0,0,0.08);
        background: #ffffff;
        font-size: 13px;
        color: #2b2b2b;
      }
      .tw-create-btn{
        all: unset;
        padding: 10px 12px;
        border-radius: 14px;
        border: 1px solid rgba(0,0,0,0.08);
        background: #111111;
        color: #ffffff;
        font-weight: 700;
        font-size: 12px;
        cursor: pointer;
      }
      .tw-quick{
        all: unset;
        margin-top: 8px;
        border: 1px dashed rgba(0,0,0,0.18);
        color: #4e4e4e;
        border-radius: 14px;
        padding: 10px 12px;
        text-align: center;
        cursor: pointer;
        font-weight: 700;
        font-size: 13px;
        background: #f7f7f7;
      }
      .tw-hidden{ display:none; }
    </style>
    <div class="tw-wrap">
      <button class="tw-button" id="tw-main" aria-label="Pin tab">
        <img class="tw-pin-img" src="${pinUrl}" alt="" />
        <span id="tw-main-text" class="tw-visually-hidden">Pin</span>
      </button>
      <div class="tw-panel tw-hidden" id="tw-panel">
        <div class="tw-title">Pin to</div>
        <div class="tw-status" id="tw-status">Choose a collection</div>
        <div class="tw-list" id="tw-list"></div>
        <button class="tw-quick" id="tw-quick">Pin to default collection</button>
        <div class="tw-create">
          <input class="tw-input" id="tw-new-name" placeholder="New collection" />
          <button class="tw-create-btn" id="tw-create">Create</button>
        </div>
      </div>
    </div>
  `;

  const mountPoint = document.body || document.documentElement;
  if (!mountPoint) return;
  mountPoint.appendChild(host);

  const mainBtn = shadow.getElementById("tw-main");
  const mainText = shadow.getElementById("tw-main-text");
  const panel = shadow.getElementById("tw-panel");
  const list = shadow.getElementById("tw-list");
  const status = shadow.getElementById("tw-status");
  const quickBtn = shadow.getElementById("tw-quick");
  const createBtn = shadow.getElementById("tw-create");
  const newNameInput = shadow.getElementById("tw-new-name");

  const positionKey = `tw_widget_pos_${location.host}`;
  getStorage(positionKey).then((pos) => {
    if (!pos || typeof pos.x !== "number" || typeof pos.y !== "number") return;
    const maxX = window.innerWidth - host.offsetWidth - 8;
    const maxY = window.innerHeight - host.offsetHeight - 8;
    const x = clamp(pos.x, 8, Math.max(8, maxX));
    const y = clamp(pos.y, 8, Math.max(8, maxY));
    host.style.left = `${x}px`;
    host.style.top = `${y}px`;
    host.style.right = "auto";
    host.style.bottom = "auto";
  });

  let statusTimer = null;
  let suppressClick = false;
  const drag = {
    active: false,
    moved: false,
    startX: 0,
    startY: 0,
    startLeft: 0,
    startTop: 0,
    target: null
  };

  function setMainText(text) {
    mainText.textContent = text;
    if (statusTimer) clearTimeout(statusTimer);
    statusTimer = setTimeout(() => {
    mainText.textContent = "Pin";
    }, 1400);
  }

  function togglePanel(show) {
    if (show) panel.classList.remove("tw-hidden");
    else panel.classList.add("tw-hidden");
  }
  function applyPosition(x, y) {
    const maxX = window.innerWidth - host.offsetWidth - 8;
    const maxY = window.innerHeight - host.offsetHeight - 8;
    const clampedX = clamp(x, 8, Math.max(8, maxX));
    const clampedY = clamp(y, 8, Math.max(8, maxY));
    host.style.left = `${clampedX}px`;
    host.style.top = `${clampedY}px`;
    host.style.right = "auto";
    host.style.bottom = "auto";
    return { x: clampedX, y: clampedY };
  }

  async function populateFolders() {
    list.innerHTML = "";
    status.textContent = "Loading collections...";

    const res = await rpc({ type: "TW_GET_DATA" }).catch(() => null);
    const folders = res?.data?.folders || [];

    if (!res || !res.ok) {
      status.textContent = "Extension is not responding. Reload.";
      return;
    }

    if (folders.length === 0) {
      status.textContent = "No collections found.";
      return;
    }

    status.textContent = "Choose a collection";

    folders.forEach((f) => {
      const btn = document.createElement("button");
      btn.className = "tw-folder";
      btn.textContent = f.name || "Collection";
      btn.addEventListener("click", async () => {
        mainBtn.setAttribute("disabled", "true");
        status.textContent = `Pinning to ${f.name}...`;
        const result = await rpc({ type: "TW_SAVE_CURRENT_TAB", folderId: f.id }).catch(() => null);
        if (result?.result?.skipped) {
          status.textContent = "Already pinned.";
          setMainText("Pinned");
        } else if (result?.ok) {
          status.textContent = "Pinned!";
          setMainText("Pinned");
          fireConfetti();
        } else {
          status.textContent = "Couldn't pin.";
          setMainText("Error");
        }
        mainBtn.removeAttribute("disabled");
        togglePanel(false);
      });
      list.appendChild(btn);
    });
  }

  quickBtn.addEventListener("click", async () => {
    mainBtn.setAttribute("disabled", "true");
    status.textContent = "Pinning...";
    const result = await rpc({ type: "TW_SAVE_CURRENT_TAB" }).catch(() => null);
    if (result?.result?.skipped) {
      status.textContent = "Already pinned.";
      setMainText("Pinned");
    } else if (result?.ok) {
      status.textContent = "Pinned!";
      setMainText("Pinned");
      fireConfetti();
    } else {
      status.textContent = "Couldn't pin.";
      setMainText("Error");
    }
    mainBtn.removeAttribute("disabled");
    togglePanel(false);
  });

  createBtn.addEventListener("click", async () => {
    const name = (newNameInput.value || "").trim();
    if (!name) return;
    status.textContent = "Creating collection...";
    const res = await rpc({ type: "TW_CREATE_FOLDER", name }).catch(() => null);
    if (res?.ok) {
      newNameInput.value = "";
      await populateFolders();
    } else {
      status.textContent = "Couldn't create collection.";
    }
  });

  function startDrag(clientX, clientY, target) {
    drag.active = true;
    drag.moved = false;
    drag.startX = clientX;
    drag.startY = clientY;
    const rect = host.getBoundingClientRect();
    drag.startLeft = rect.left;
    drag.startTop = rect.top;
    drag.target = target || null;
    if (drag.target) drag.target.classList.add("tw-dragging");
  }

  function moveDrag(clientX, clientY) {
    if (!drag.active) return;
    const dx = clientX - drag.startX;
    const dy = clientY - drag.startY;
    if (!drag.moved && Math.hypot(dx, dy) > 6) drag.moved = true;
    if (!drag.moved) return;
    const pos = applyPosition(drag.startLeft + dx, drag.startTop + dy);
    drag.lastPos = pos;
  }

  function endDrag() {
    if (!drag.active) return;
    drag.active = false;
    if (drag.target) {
      drag.target.classList.remove("tw-dragging");
      drag.target = null;
    }
    if (drag.moved) {
      suppressClick = true;
      const left = parseFloat(host.style.left);
      const top = parseFloat(host.style.top);
      if (!Number.isNaN(left) && !Number.isNaN(top)) {
        setStorage(positionKey, { x: left, y: top });
      }
      setTimeout(() => { suppressClick = false; }, 0);
    }
  }

  function bindDrag(el) {
    if (!el) return;
    el.addEventListener("mousedown", (e) => {
      if (e.button != 0) return;
      e.preventDefault();
      startDrag(e.clientX, e.clientY, el);
    });

    el.addEventListener("touchstart", (e) => {
      if (e.touches.length != 1) return;
      e.preventDefault();
      const t = e.touches[0];
      startDrag(t.clientX, t.clientY, el);
    }, { passive: false });
  }

  bindDrag(mainBtn);

  document.addEventListener("mousemove", (e) => moveDrag(e.clientX, e.clientY));
  document.addEventListener("mouseup", endDrag);

  document.addEventListener("touchmove", (e) => {
    if (!drag.active) return;
    const t = e.touches[0];
    if (!t) return;
    e.preventDefault();
    moveDrag(t.clientX, t.clientY);
  }, { passive: false });

  document.addEventListener("touchend", endDrag);
  document.addEventListener("touchcancel", endDrag);
  mainBtn.addEventListener("click", async (e) => {
    if (suppressClick) return;
    e.preventDefault();
    const isOpen = !panel.classList.contains("tw-hidden");
    if (isOpen) {
      togglePanel(false);
      return;
    }
    togglePanel(true);
    await populateFolders();
  });

  window.addEventListener("resize", () => {
    if (host.style.left && host.style.top) {
      const x = parseFloat(host.style.left);
      const y = parseFloat(host.style.top);
      if (!Number.isNaN(x) && !Number.isNaN(y)) {
        applyPosition(x, y);
      }
    }
  });

  document.addEventListener("click", (e) => {
    const path = e.composedPath ? e.composedPath() : [];
    if (path.includes(host)) return;
    togglePanel(false);
  }, true);
}

function ensureWidget() {
  if (!shouldShowWidget()) return;
  mountWidget();
}

let observerStarted = false;
function startObserver() {
  if (observerStarted || !document.documentElement) return;
  observerStarted = true;
  const obs = new MutationObserver(() => {
    if (!document.getElementById("tw-widget-host")) {
      ensureWidget();
    }
  });
  obs.observe(document.documentElement, { childList: true, subtree: true });
}

function init() {
  ensureWidget();
  startObserver();
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init, { once: true });
} else {
  init();
}

let lastUrl = location.href;
setInterval(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    const host = document.getElementById("tw-widget-host");
    if (host) host.remove();
  }
  ensureWidget();
}, 1500);

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== "TW_SCRAPE") return;

  const url = location.href;
  const site = location.hostname;

  const ogTitle = getMeta('meta[property="og:title"]');
  const ogImage = getMeta('meta[property="og:image"]');

  const title = (ogTitle || document.title || "").trim();

  const products = parseJsonLdProducts();
  const { price, currency } = extractPriceFromJsonLd(products);
  const fallbackPrice = price ? "" : extractPriceFallback();

  const image =
    extractImageFromJsonLd(products) ||
    normalizeUrl(ogImage) ||
    extractImageFromMeta() ||
    extractImageFromDom();

  const item = {
    url,
    site,
    title,
    image: image || "",
    price: (price || fallbackPrice || "").trim(),
    currency: (currency || "").trim()
  };

  sendResponse({ ok: true, item });
});
